/*
 * Inherited-master atomic-KMS plane-flip witness for the pinned Linux VC4
 * fixture.
 *
 * The earlier witnesses establish a native mode and complete one legacy page
 * flip on the shared drm_file.  This child enables DRM_CLIENT_CAP_ATOMIC,
 * discovers the active primary plane and its FB_ID property through the object
 * property UAPI, validates the replacement state with TEST_ONLY, then submits
 * a nonblocking evented atomic commit.  The completion event, GETPLANE, and
 * GETCRTC must all agree that the third framebuffer reached scanout.
 */

#ifndef VC4_KMS_ATOMIC_STANDALONE
#include "linux-kms-pageflip-probe.inc.c"
#endif

#include <drm.h>
#include <drm_mode.h>
#include <poll.h>

#define VC4_ATOMIC_TIMEOUT_SECONDS      30U
#define VC4_ATOMIC_VISUAL_HOLD_SECONDS   3U
#define VC4_ATOMIC_POLL_ATTEMPTS        20U
#define VC4_ATOMIC_POLL_TIMEOUT_MS     500
#define VC4_ATOMIC_MAX_PLANES           32U
#define VC4_ATOMIC_MAX_PROPERTIES       64U
#define VC4_ATOMIC_USER_DATA UINT64_C(0x56433441544f4d49)

struct vc4_atomic_plane_selection {
    uint32_t plane_id;
    uint32_t fb_id_property;
};

static int vc4_atomic_fail(const char *stage)
{
    char message[192];
    int saved_errno = errno != 0 ? errno : EIO;

    snprintf(message, sizeof(message),
             "VC4_LINUX_KMS_ATOMIC_FAILED stage=%s errno=%d\n",
             stage, saved_errno);
    marker(message);
    errno = saved_errno;
    return -1;
}

static int vc4_atomic_ioctl(int fd, unsigned long request, void *argument,
                            const char *stage)
{
    int result;

    do {
        result = ioctl(fd, request, argument);
    } while (result < 0 && errno == EINTR);
    if (result < 0) {
        return vc4_atomic_fail(stage);
    }
    return 0;
}

static int vc4_atomic_enable_client(int fd)
{
    struct drm_set_client_cap capability = {
        .capability = DRM_CLIENT_CAP_ATOMIC,
        .value = 1,
    };

    if (vc4_atomic_ioctl(fd, DRM_IOCTL_SET_CLIENT_CAP, &capability,
                         "set-client-cap-atomic") < 0) {
        return -1;
    }
    marker("VC4_LINUX_KMS_ATOMIC_CLIENT_CAP_OK\n");
    return 0;
}

static int vc4_atomic_find_fb_property(int fd, uint32_t plane_id,
                                       uint32_t *property_id)
{
    struct drm_mode_obj_get_properties properties = {
        .obj_id = plane_id,
        .obj_type = DRM_MODE_OBJECT_PLANE,
    };
    uint32_t ids[VC4_ATOMIC_MAX_PROPERTIES] = { 0 };
    uint64_t values[VC4_ATOMIC_MAX_PROPERTIES] = { 0 };

    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_OBJ_GETPROPERTIES, &properties,
                         "get-plane-property-count") < 0) {
        return -1;
    }
    if (properties.count_props == 0 ||
        properties.count_props > VC4_ATOMIC_MAX_PROPERTIES) {
        errno = properties.count_props == 0 ? ENOENT : EOVERFLOW;
        return vc4_atomic_fail("plane-property-capacity");
    }

    properties.props_ptr = (uintptr_t)ids;
    properties.prop_values_ptr = (uintptr_t)values;
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_OBJ_GETPROPERTIES, &properties,
                         "get-plane-properties") < 0) {
        return -1;
    }
    if (properties.count_props == 0 ||
        properties.count_props > VC4_ATOMIC_MAX_PROPERTIES) {
        errno = EAGAIN;
        return vc4_atomic_fail("plane-property-race");
    }

    for (uint32_t index = 0; index < properties.count_props; index++) {
        struct drm_mode_get_property property = {
            .prop_id = ids[index],
        };

        if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_GETPROPERTY, &property,
                             "get-plane-property") < 0) {
            return -1;
        }
        property.name[DRM_PROP_NAME_LEN - 1] = '\0';
        report("VC4_LINUX_KMS_ATOMIC_PROPERTY plane=%u id=%u "
               "name=%.32s value=%llu flags=0x%08x\n",
               plane_id, property.prop_id, property.name,
               (unsigned long long)values[index], property.flags);
        if (strcmp(property.name, "FB_ID") == 0) {
            *property_id = property.prop_id;
            return 0;
        }
    }

    errno = ENOENT;
    return vc4_atomic_fail("fb-id-property-missing");
}

static int vc4_atomic_select_active_plane(
    int fd, uint32_t crtc_id, uint32_t framebuffer_id,
    struct vc4_atomic_plane_selection *selection)
{
    struct drm_mode_get_plane_res resources = { 0 };
    uint32_t plane_ids[VC4_ATOMIC_MAX_PLANES] = { 0 };

    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_GETPLANERESOURCES, &resources,
                         "get-plane-count") < 0) {
        return -1;
    }
    if (resources.count_planes == 0 ||
        resources.count_planes > VC4_ATOMIC_MAX_PLANES) {
        errno = resources.count_planes == 0 ? ENODEV : EOVERFLOW;
        return vc4_atomic_fail("plane-capacity");
    }

    resources.plane_id_ptr = (uintptr_t)plane_ids;
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_GETPLANERESOURCES, &resources,
                         "get-planes") < 0) {
        return -1;
    }
    if (resources.count_planes == 0 ||
        resources.count_planes > VC4_ATOMIC_MAX_PLANES) {
        errno = EAGAIN;
        return vc4_atomic_fail("plane-race");
    }

    for (uint32_t index = 0; index < resources.count_planes; index++) {
        struct drm_mode_get_plane plane = {
            .plane_id = plane_ids[index],
        };
        uint32_t property_id = 0;

        if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_GETPLANE, &plane,
                             "get-plane") < 0) {
            return -1;
        }
        report("VC4_LINUX_KMS_ATOMIC_PLANE id=%u crtc=%u fb=%u "
               "possible_crtcs=0x%08x formats=%u\n",
               plane.plane_id, plane.crtc_id, plane.fb_id,
               plane.possible_crtcs, plane.count_format_types);
        if (plane.crtc_id != crtc_id || plane.fb_id != framebuffer_id) {
            continue;
        }
        if (vc4_atomic_find_fb_property(fd, plane.plane_id,
                                        &property_id) < 0) {
            return -1;
        }
        selection->plane_id = plane.plane_id;
        selection->fb_id_property = property_id;
        report("VC4_LINUX_KMS_ATOMIC_PLANE_OK plane=%u property=%u\n",
               selection->plane_id, selection->fb_id_property);
        marker("VC4_LINUX_KMS_ATOMIC_PLANE_OK\n");
        return 0;
    }

    errno = ENODEV;
    return vc4_atomic_fail("active-primary-plane-missing");
}

static void vc4_atomic_fill_pattern(void *mapping, uint32_t pitch,
                                    uint32_t width, uint32_t height)
{
    for (uint32_t y = 0; y < height; y++) {
        uint32_t *row =
            (uint32_t *)((uint8_t *)mapping + (size_t)y * pitch);

        for (uint32_t x = 0; x < width; x++) {
            uint32_t checker = ((x / 40) ^ (y / 40)) & 1;
            uint32_t red = height > 1 ?
                           255 - y * 255 / (height - 1) : 0xff;
            uint32_t green = checker ? 0xff : 0x24;
            uint32_t blue = width > 1 ? x * 255 / (width - 1) : 0;

            row[x] = (red << 16) | (green << 8) | blue;
        }
    }
}

static int vc4_atomic_wait_event(int fd, uint32_t crtc_id,
                                 uint64_t expected_user_data)
{
    uint64_t event_words[512];
    uint8_t *event_bytes = (uint8_t *)event_words;

    for (unsigned int attempt = 0;
         attempt < VC4_ATOMIC_POLL_ATTEMPTS;
         attempt++) {
        struct pollfd descriptor = {
            .fd = fd,
            .events = POLLIN,
        };
        int poll_result;
        ssize_t length;
        size_t offset = 0;

        do {
            poll_result = poll(&descriptor, 1,
                               VC4_ATOMIC_POLL_TIMEOUT_MS);
        } while (poll_result < 0 && errno == EINTR);
        if (poll_result < 0) {
            return vc4_atomic_fail("poll-event");
        }
        if (poll_result == 0) {
            continue;
        }
        if (descriptor.revents & (POLLERR | POLLHUP | POLLNVAL)) {
            errno = EIO;
            return vc4_atomic_fail("poll-event-state");
        }
        if (!(descriptor.revents & POLLIN)) {
            continue;
        }

        do {
            length = read(fd, event_words, sizeof(event_words));
        } while (length < 0 && errno == EINTR);
        if (length < 0 && errno == EAGAIN) {
            continue;
        }
        if (length <= 0) {
            if (length == 0) {
                errno = EIO;
            }
            return vc4_atomic_fail("read-event");
        }

        while (offset < (size_t)length) {
            struct drm_event event;

            if ((size_t)length - offset < sizeof(event)) {
                errno = EPROTO;
                return vc4_atomic_fail("event-header-short");
            }
            memcpy(&event, event_bytes + offset, sizeof(event));
            if (event.length < sizeof(event) ||
                event.length > (size_t)length - offset) {
                errno = EPROTO;
                return vc4_atomic_fail("event-length");
            }
            if (event.type == DRM_EVENT_FLIP_COMPLETE &&
                event.length >= sizeof(struct drm_event_vblank)) {
                struct drm_event_vblank vblank;

                memcpy(&vblank, event_bytes + offset, sizeof(vblank));
                report("VC4_LINUX_KMS_ATOMIC_EVENT type=%u length=%u "
                       "user=0x%016llx sequence=%u crtc=%u\n",
                       vblank.base.type, vblank.base.length,
                       (unsigned long long)vblank.user_data,
                       vblank.sequence, vblank.crtc_id);
                if (vblank.user_data == expected_user_data &&
                    (vblank.crtc_id == 0 || vblank.crtc_id == crtc_id)) {
                    marker("VC4_LINUX_KMS_ATOMIC_EVENT_OK\n");
                    return 0;
                }
            }
            offset += event.length;
        }
    }

    errno = ETIMEDOUT;
    return vc4_atomic_fail("wait-event-timeout");
}

static int vc4_atomic_run(int fd)
{
    struct vc4_modeset_selection modeset = { 0 };
    struct vc4_atomic_plane_selection plane = { 0 };
    struct drm_mode_crtc current = { 0 };
    struct drm_mode_create_dumb create = { 0 };
    struct drm_mode_map_dumb map = { 0 };
    struct drm_mode_fb_cmd2 framebuffer = { 0 };
    uint32_t object_ids[1];
    uint32_t property_counts[1] = { 1 };
    uint32_t property_ids[1];
    uint64_t property_values[1];
    struct drm_mode_atomic atomic = { 0 };
    struct drm_mode_get_plane final_plane = { 0 };
    void *mapping = MAP_FAILED;

    marker("VC4_LINUX_KMS_ATOMIC_START\n");
    if (fd < 0) {
        errno = EBADF;
        return vc4_atomic_fail("invalid-master-fd");
    }
    if (vc4_atomic_enable_client(fd) < 0) {
        return -1;
    }
    if (vc4_modeset_select(fd, &modeset) < 0) {
        return vc4_atomic_fail("select-active-crtc");
    }

    current.crtc_id = modeset.crtc_id;
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_GETCRTC, &current,
                         "getcrtc-before") < 0) {
        return -1;
    }
    if (!current.mode_valid || current.fb_id == 0 ||
        current.mode.hdisplay == 0 || current.mode.vdisplay == 0) {
        errno = ENODEV;
        return vc4_atomic_fail("crtc-not-active");
    }
    if (vc4_atomic_select_active_plane(fd, current.crtc_id, current.fb_id,
                                       &plane) < 0) {
        return -1;
    }

    create.width = current.mode.hdisplay;
    create.height = current.mode.vdisplay;
    create.bpp = 32;
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_CREATE_DUMB, &create,
                         "create-dumb") < 0) {
        return -1;
    }
    if (create.handle == 0 || create.pitch == 0 || create.size == 0) {
        errno = EIO;
        return vc4_atomic_fail("create-dumb-invalid");
    }
    report("VC4_LINUX_KMS_ATOMIC_DUMB_OK handle=%u pitch=%u size=%llu\n",
           create.handle, create.pitch, (unsigned long long)create.size);
    marker("VC4_LINUX_KMS_ATOMIC_DUMB_OK\n");

    map.handle = create.handle;
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_MAP_DUMB, &map,
                         "map-dumb") < 0) {
        return -1;
    }
    mapping = mmap(NULL, create.size, PROT_READ | PROT_WRITE, MAP_SHARED,
                   fd, (off_t)map.offset);
    if (mapping == MAP_FAILED) {
        return vc4_atomic_fail("mmap-dumb");
    }
    vc4_atomic_fill_pattern(mapping, create.pitch,
                            create.width, create.height);
    __sync_synchronize();
    marker("VC4_LINUX_KMS_ATOMIC_MAP_OK\n");

    framebuffer.width = create.width;
    framebuffer.height = create.height;
    framebuffer.pixel_format = VC4_MODESET_DRM_FORMAT_XRGB8888;
    framebuffer.handles[0] = create.handle;
    framebuffer.pitches[0] = create.pitch;
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_ADDFB2, &framebuffer,
                         "addfb2") < 0) {
        return -1;
    }
    report("VC4_LINUX_KMS_ATOMIC_FB_OK fb=%u old_fb=%u\n",
           framebuffer.fb_id, current.fb_id);
    marker("VC4_LINUX_KMS_ATOMIC_FB_OK\n");

    object_ids[0] = plane.plane_id;
    property_ids[0] = plane.fb_id_property;
    property_values[0] = framebuffer.fb_id;
    atomic.count_objs = 1;
    atomic.objs_ptr = (uintptr_t)object_ids;
    atomic.count_props_ptr = (uintptr_t)property_counts;
    atomic.props_ptr = (uintptr_t)property_ids;
    atomic.prop_values_ptr = (uintptr_t)property_values;
    atomic.flags = DRM_MODE_ATOMIC_TEST_ONLY;
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_ATOMIC, &atomic,
                         "atomic-test-only") < 0) {
        return -1;
    }
    marker("VC4_LINUX_KMS_ATOMIC_TEST_OK\n");

    atomic.flags = DRM_MODE_ATOMIC_NONBLOCK | DRM_MODE_PAGE_FLIP_EVENT;
    atomic.user_data = VC4_ATOMIC_USER_DATA;
    marker("VC4_LINUX_KMS_ATOMIC_COMMIT_START\n");
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_ATOMIC, &atomic,
                         "atomic-commit") < 0) {
        return -1;
    }
    marker("VC4_LINUX_KMS_ATOMIC_QUEUED\n");

    if (vc4_atomic_wait_event(fd, current.crtc_id,
                              VC4_ATOMIC_USER_DATA) < 0) {
        return -1;
    }

    final_plane.plane_id = plane.plane_id;
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_GETPLANE, &final_plane,
                         "get-plane-after") < 0) {
        return -1;
    }
    memset(&current, 0, sizeof(current));
    current.crtc_id = modeset.crtc_id;
    if (vc4_atomic_ioctl(fd, DRM_IOCTL_MODE_GETCRTC, &current,
                         "getcrtc-after") < 0) {
        return -1;
    }
    if (final_plane.fb_id != framebuffer.fb_id ||
        current.fb_id != framebuffer.fb_id) {
        report("VC4_LINUX_KMS_ATOMIC_FB_MISMATCH expected=%u "
               "plane=%u crtc=%u\n",
               framebuffer.fb_id, final_plane.fb_id, current.fb_id);
        errno = EIO;
        return vc4_atomic_fail("current-fb-mismatch");
    }
    marker("VC4_LINUX_KMS_ATOMIC_CURRENT_FB_OK\n");
    marker("VC4_LINUX_KMS_ATOMIC_VISUAL_READY\n");
    sleep(VC4_ATOMIC_VISUAL_HOLD_SECONDS);

    (void)munmap(mapping, create.size);
    marker("VC4_LINUX_KMS_ATOMIC_OK\n");
    return 0;
}

static int vc4_kms_atomic_supervise(int master_fd)
{
    struct timespec delay = {
        .tv_sec = 0,
        .tv_nsec = VC4_MODESET_POLL_NS,
    };
    pid_t child;

    marker("VC4_LINUX_KMS_ATOMIC_SUPERVISOR_START\n");
    child = fork();
    if (child < 0) {
        return vc4_atomic_fail("fork");
    }
    if (child == 0) {
        alarm(VC4_ATOMIC_TIMEOUT_SECONDS - 2);
        _exit(vc4_atomic_run(master_fd) == 0 ? 0 : 1);
    }

    for (unsigned int iteration = 0;
         iteration < VC4_ATOMIC_TIMEOUT_SECONDS * 10;
         iteration++) {
        int status;
        pid_t result;

        do {
            result = waitpid(child, &status, WNOHANG);
        } while (result < 0 && errno == EINTR);
        if (result == child) {
            if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
                marker("VC4_LINUX_KMS_ATOMIC_SUPERVISOR_OK\n");
                return 0;
            }
            if (WIFEXITED(status)) {
                report("VC4_LINUX_KMS_ATOMIC_CHILD_EXIT status=%d\n",
                       WEXITSTATUS(status));
            } else if (WIFSIGNALED(status)) {
                int signal = WTERMSIG(status);

                report("VC4_LINUX_KMS_ATOMIC_CHILD_SIGNAL signal=%d\n",
                       signal);
                if (signal == SIGALRM) {
                    marker("VC4_LINUX_KMS_ATOMIC_TIMEOUT\n");
                }
            }
            marker("VC4_LINUX_KMS_ATOMIC_SUPERVISOR_FAILED\n");
            return -1;
        }
        if (result < 0) {
            return vc4_atomic_fail("waitpid");
        }
        nanosleep(&delay, NULL);
    }

    (void)kill(child, SIGKILL);
    (void)waitpid(child, NULL, 0);
    marker("VC4_LINUX_KMS_ATOMIC_TIMEOUT\n");
    return -1;
}
